# Log file for monitoring
$logFile = "C:\Scripts\mullvad_log.txt"
Add-Content $logFile "$(Get-Date): Mullvad Auto-Disconnect Monitor started"

# Function to disconnect Mullvad VPN with retries
function Disconnect-Mullvad {
    param($reason)
    try {
        Add-Content $logFile "$(Get-Date): Shutdown detected ($reason) - disconnecting Mullvad VPN"
        
        # Multiple disconnect attempts for reliability
        for ($i = 1; $i -le 3; $i++) {
            $output = cmd /c "mullvad disconnect" 2>&1
            Start-Sleep -Seconds 2
            
            # Check if actually disconnected
            $currentStatus = cmd /c "mullvad status" 2>&1
            if ($currentStatus -match "Disconnected") {
                Add-Content $logFile "$(Get-Date): Mullvad successfully disconnected"
                break
            }
        }
        
        Add-Content $logFile "$(Get-Date): Disconnect sequence completed"
        
    } catch {
        Add-Content $logFile "$(Get-Date): Error during disconnect: $($_.Exception.Message)"
    }
}

# PowerShell exit handler - ensures disconnect when PowerShell closes
$null = Register-EngineEvent PowerShell.Exiting -Action {
    Add-Content "C:\Scripts\mullvad_log.txt" "$(Get-Date): PowerShell exiting - disconnecting Mullvad"
    try { 
        cmd /c "mullvad disconnect" 
        Start-Sleep -Seconds 3
        cmd /c "mullvad disconnect"  # Second attempt
    } catch {}
}

Add-Content $logFile "$(Get-Date): Monitoring active"

# FIXED monitoring - REMOVED problematic process count detection
$heartbeatCounter = 0

try {
    while ($true) {
        Start-Sleep -Seconds 2  # Fast checking for early detection
        
        # Method 1: shutdown.exe detection (MOST RELIABLE - KEEP THIS!)
        $shutdown = Get-Process -Name "shutdown" -ErrorAction SilentlyContinue
        if ($shutdown) {
            Add-Content $logFile "$(Get-Date): shutdown.exe detected"
            Disconnect-Mullvad "shutdown process"
            Start-Sleep -Seconds 10  # Wait long enough for disconnect to complete
            break  # Stop monitoring after disconnect
        }
        
        # REMOVED: Method 2 - Process count detection (WAS CAUSING FALSE POSITIVES)
        # This was triggering constantly because normal Windows systems run with 160-200 processes
        
        # Method 3: LogonUI detection (as backup)
        $logonUI = Get-Process -Name "LogonUI" -ErrorAction SilentlyContinue
        if ($logonUI) {
            Disconnect-Mullvad "logoff screen"
        }
        
        # Method 4: Session manager shutdown preparation
        try {
            $sessionManager = Get-Process -Name "smss" -ErrorAction SilentlyContinue
            if (-not $sessionManager) {
                Disconnect-Mullvad "session manager shutdown"
            }
        } catch {}
        
        # Method 5: User session changes (for logoff detection)
        try {
            $sessionInfo = quser 2>$null
            if (-not $sessionInfo -or $sessionInfo.Length -eq 0) {
                Disconnect-Mullvad "user logoff"
            }
        } catch {
            # quser failing can also indicate session ending
            Disconnect-Mullvad "session ending"
        }
        
        # Heartbeat every 10 minutes
        $heartbeatCounter++
        if ($heartbeatCounter -ge 300) {  # 300 * 2 seconds = 10 minutes
            Add-Content $logFile "$(Get-Date): Monitor running normally"
            $heartbeatCounter = 0
        }
    }
} catch {
    Add-Content $logFile "$(Get-Date): Monitor terminated: $($_.Exception.Message)"
    Disconnect-Mullvad "exception"
}